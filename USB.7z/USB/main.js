var HID=require('node-hid');
console.log(HID.devices());

